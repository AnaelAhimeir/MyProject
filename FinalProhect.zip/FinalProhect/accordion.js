
var accordions = document.querySelectorAll('.accordion-header');
for (var i = 0; i < accordions.length; i++) {
  accordions[i].addEventListener('click', toggleAccordion);
}

function toggleAccordion() {
  this.classList.toggle('active');
  
  var panel = this.nextElementSibling;
  if (panel.style.display === 'block') {
    panel.style.display = 'none';
  } else {
    panel.style.display = 'block';
  }
}