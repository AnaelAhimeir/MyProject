document.getElementById('eventForm').addEventListener('submit', function(event) {
    event.preventDefault(); // מניעת טעינת העמוד מחדש לאחר שליחת הטופס

    var eventName = document.getElementById('eventName').value;
    var eventDate = document.getElementById('eventDate').value;

    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl);

    calendar.addEvent({
        title: eventName,
        start: eventDate
    });
});
